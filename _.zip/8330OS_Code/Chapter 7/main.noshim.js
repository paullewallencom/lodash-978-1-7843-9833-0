require.config({
	paths: {
		jquery: '../lib/jquery.min',
		underscore: '../lib/lodash-amd/main'
	}
});
